﻿$base = "http://localhost:9000"
$files = Get-ChildItem "C:\orspex-website-vercel" -Recurse -Filter "*.html"

$links = @()
foreach ($file in $files) {
    $content = Get-Content $file.FullName -Raw
    $matches = [regex]::Matches($content, '(?:href|src)="([^"]+)"')
    foreach ($m in $matches) {
        $url = $m.Groups[1].Value
        if ($url -match '^(#|mailto:|javascript:|https?://)') { continue }
        $relativeDir = $file.DirectoryName.Replace("C:\orspex-website-vercel", "").Replace("\", "/")
        $full = "$base$relativeDir/$url"
        $links += [PSCustomObject]@{ Page = $file.Name; Link = $url; URL = $full }
    }
}

foreach ($l in $links) {
    try {
        $r = Invoke-WebRequest -Uri $l.URL -Method Head -UseBasicParsing -ErrorAction Stop
        Write-Host "OK   $($r.StatusCode)  $($l.URL)" -ForegroundColor Green
    } catch {
        Write-Host "FAIL      $($l.URL)  (from $($l.Page))" -ForegroundColor Red
    }
}
